﻿Imports System
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

<assembly: AssemblyTitle("Plugin")>
<assembly: AssemblyDescription("")>
<assembly: AssemblyConfiguration("")>
<assembly: AssemblyCompany("")>
<assembly: AssemblyProduct("Plugin")>
<assembly: AssemblyCopyright("")>
<assembly: AssemblyTrademark("")>
<assembly: AssemblyCulture("")>
<assembly: ComVisible(False)>
<assembly: CLSCompliant(True)>
<assembly: AssemblyVersion("0.0.0.0")>
